# CardingCalc — Textile Engineering Calculator

CardingCalc is a beginner-friendly Streamlit web app for second-year Textile
Engineering students. It demonstrates selected carding-related calculations
using interactive inputs and shows formulas, units and working steps.

## Features

- Cylinder surface speed (m/s and m/min)
- Feed-lap linear density (g/m) from mass and length
- Draft from input and output linear density
- Simplified theoretical production (kg/h and kg/24 h)
- Formula explanations and limitations

## Project files

```text
CardingCalc/
├── app.py
├── requirements.txt
└── README.md
```

## Run locally

1. Install Python.
2. Open a terminal in this project folder.
3. Install the package:

   ```bash
   pip install -r requirements.txt
   ```

4. Start the app:

   ```bash
   streamlit run app.py
   ```

## Deploy with GitHub and Streamlit Community Cloud

1. Sign in to GitHub and create a repository, for example `cardingcalc`.
2. Add `app.py`, `requirements.txt` and this `README.md` to the repository.
3. Open Streamlit Community Cloud and connect your GitHub account.
4. Choose **Create app**.
5. Select your repository, branch (usually `main`) and main file path `app.py`.
6. Deploy. Streamlit will provide a live URL after successful deployment.

## Calculation assumptions

- Cylinder surface speed: `V = π × D × N / 60`, with diameter `D` in metres
  and rotational speed `N` in rpm; output is m/s.
- Feed-lap linear density: `mass (kg) × 1000 / length (m)`, giving g/m.
- Draft in this app: `input linear density / output linear density`, with both
  values entered in g/m.
- Theoretical production: `delivery speed (m/min) × output linear density (g/m)
  × 60 / 1000`, giving kg/h.

These are educational calculations, not a complete machine model. Textile
courses and machine designs may define draft and production differently.
Confirm the required formula and units from your lecturer's notes or the
machine documentation before relying on a result. The 24-hour production
estimate assumes uninterrupted operation and is not actual mill production.

## Technology

- Python
- Streamlit

## Student project

Created as a learning project for Textile Engineering. The purpose is to
practise formulas, units, interactive inputs and web-app deployment.
