import math
import streamlit as st

st.set_page_config(
    page_title="CardingCalc | Textile Engineering",
    page_icon="🧵",
    layout="wide",
)

st.markdown("""
<style>
    .stApp { background: linear-gradient(180deg, #f5faf8 0%, #ffffff 42%); }
    h1, h2, h3 { color: #124b45; }
    div[data-testid="stMetric"] {
        background: #eef6f2;
        border: 1px solid #d4e7de;
        padding: 14px;
        border-radius: 12px;
    }
</style>
""", unsafe_allow_html=True)

st.title("🧵 CardingCalc")
st.subheader("Textile Engineering • Carding Calculation Tool")
st.write(
    "A student-friendly calculator for exploring carding-machine speed, "
    "feed-lap linear density, draft and theoretical production."
)
st.info(
    "Learning tool: enter values with the units shown. Results depend on the "
    "formula assumptions described in each section. Check machine-specific "
    "formulas against your lecturer's notes before using them in a report."
)

tab1, tab2, tab3, tab4 = st.tabs([
    "Cylinder Speed", "Feed Lap", "Draft", "Production"
])

with tab1:
    st.header("Cylinder Surface Speed")
    st.write("Calculate the surface speed of a rotating cylinder.")
    c1, c2, c3 = st.columns(3)
    with c1:
        diameter_m = st.number_input(
            "Cylinder diameter (m)", min_value=0.001, value=1.28,
            step=0.01, format="%.3f", key="c_d"
        )
    with c2:
        rpm = st.number_input(
            "Cylinder speed (rpm)", min_value=0.0, value=500.0,
            step=10.0, key="c_rpm"
        )
    with c3:
        st.caption("Formula")
        st.latex(r"V = \\frac{\\pi D N}{60}")
        st.caption("D in metres; N in rpm; V in m/s.")
    if diameter_m > 0:
        speed_ms = math.pi * diameter_m * rpm / 60
        speed_m_min = speed_ms * 60
        a, b = st.columns(2)
        a.metric("Surface speed", f"{speed_ms:.3f} m/s")
        b.metric("Surface speed", f"{speed_m_min:.2f} m/min")
        st.write(
            f"Working: π × {diameter_m:.3f} m × {rpm:.2f} rpm ÷ 60 "
            f"= **{speed_ms:.3f} m/s**."
        )

with tab2:
    st.header("Feed Lap Linear Density")
    st.write("Find mass per unit length from the entered lap weight and length.")
    c1, c2 = st.columns(2)
    with c1:
        lap_mass = st.number_input(
            "Feed lap mass (kg)", min_value=0.001, value=20.0,
            step=0.5, format="%.3f", key="lap_mass"
        )
    with c2:
        lap_length = st.number_input(
            "Feed lap length (m)", min_value=0.001, value=30.0,
            step=1.0, format="%.3f", key="lap_length"
        )
    st.latex(r"\\text{Linear density (g/m)} = \\frac{\\text{mass (kg)}\\times1000}{\\text{length (m)}}")
    if lap_length > 0:
        density_g_m = lap_mass * 1000 / lap_length
        st.metric("Feed lap linear density", f"{density_g_m:.3f} g/m")
        st.write(
            f"Working: ({lap_mass:.3f} × 1000) ÷ {lap_length:.3f} "
            f"= **{density_g_m:.3f} g/m**."
        )
        st.caption(
            "This calculates average linear density only. It does not account "
            "for lap variation, moisture regain or waste."
        )

with tab3:
    st.header("Draft Calculator")
    st.write(
        "For this calculator, draft is defined as input linear density divided "
        "by output linear density, with both values in the same units."
    )
    c1, c2 = st.columns(2)
    with c1:
        input_density = st.number_input(
            "Input linear density (g/m)", min_value=0.001, value=600.0,
            step=10.0, key="draft_in"
        )
    with c2:
        output_density = st.number_input(
            "Output linear density (g/m)", min_value=0.001, value=5.0,
            step=0.5, key="draft_out"
        )
    st.latex(r"\\text{Draft} = \\frac{\\text{Input linear density}}{\\text{Output linear density}}")
    if output_density > 0:
        draft = input_density / output_density
        st.metric("Calculated draft", f"{draft:.3f} ×")
        st.write(
            f"Working: {input_density:.3f} g/m ÷ {output_density:.3f} g/m "
            f"= **{draft:.3f}**."
        )
        st.warning(
            "Some textile courses calculate draft using different machine "
            "delivery/feed quantities or machine-specific roller/cylinder "
            "speed ratios. Use the definition required by your class."
        )

with tab4:
    st.header("Theoretical Delivery Production")
    st.write(
        "Estimate mass production from delivery speed and output linear density. "
        "This is a simplified theoretical calculation."
    )
    c1, c2 = st.columns(2)
    with c1:
        delivery_speed = st.number_input(
            "Delivery speed (m/min)", min_value=0.0, value=100.0,
            step=5.0, key="prod_speed"
        )
    with c2:
        output_g_m = st.number_input(
            "Output linear density (g/m)", min_value=0.001, value=5.0,
            step=0.5, key="prod_density"
        )
    st.latex(r"\\text{Production (kg/h)} = \\frac{v\\times T\\times60}{1000}")
    st.caption("v = delivery speed in m/min; T = output linear density in g/m.")
    production = delivery_speed * output_g_m * 60 / 1000
    a, b = st.columns(2)
    a.metric("Theoretical production", f"{production:.3f} kg/h")
    b.metric("Theoretical production", f"{production * 24:.3f} kg/24 h")
    st.write(
        f"Working: {delivery_speed:.3f} × {output_g_m:.3f} × 60 ÷ 1000 "
        f"= **{production:.3f} kg/h**."
    )
    st.caption(
        "Actual production may be lower because of machine stops, waste, "
        "efficiency, quality settings and other operating conditions. "
        "The 24-hour value assumes continuous operation."
    )

st.divider()
st.header("Quick Notes")
with st.expander("What do the terms mean?"):
    st.markdown("""
    - **RPM:** revolutions per minute.
    - **Cylinder surface speed:** the linear speed at the cylinder surface.
    - **Linear density:** mass divided by length, such as g/m.
    - **Draft:** a ratio describing the reduction in linear density under the
      definition used in this app.
    - **Theoretical production:** calculated output before allowances for
      stoppages, waste or operating efficiency.
    """)
with st.expander("Limitations of this student app"):
    st.markdown("""
    1. It uses simplified, explicitly stated equations.
    2. It does not model all carding-machine components or gearing.
    3. It does not automatically apply machine efficiency or waste percentage.
    4. It does not replace machine manuals, laboratory measurements or course notes.
    5. Always check units and the required definition before submitting a result.
    """)

st.caption("CardingCalc • Mini-project for Textile Engineering students")
